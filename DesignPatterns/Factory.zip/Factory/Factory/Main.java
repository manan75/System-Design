package Factory;
import java.util.*;
public class Main {
   public static void main(String[] args) throws Exception {
    Scanner scan = new Scanner(System.in);
    factory f = new factory();
    BuyerInventory buyer = new BuyerInventory();
    System.out.println("Welcom to Manan Retails!");
    int isBuying =1;
    while(isBuying==1){
        System.out.println("Do you wish to buy cars?: (Y/N)");
        String choice = scan.next();
        if (choice.equalsIgnoreCase("N")) { // Use equalsIgnoreCase for better comparison
            break;
        }
        else{
            String carBought = f.buyMenu();


            switch(carBought){
                case "Audi": {
                    System.out.println("Congrats you bought an audi! The details of your purchase are: ");
        
                    Audi audi = f.getAudi();
                    buyer.storeInGarage(audi);
                    audi.displayDetails();
                    break;
                }
                case "BMW":{
                    System.out.println("Congrats you bought a BMW! The details of your purchase are: ");
                    BMW bmw = f.getBmw();
                    buyer.storeInGarage(bmw);
                    bmw.displayDetails();
                    break;
                }
                case "Ferrari": {
                    System.out.println("Congrats you bought an ferrari! The details of your purchase are: ");
                    Ferrari ferrari = f.getFerrari();
                    buyer.storeInGarage(ferrari);
                    ferrari.displayDetails();
                    break;
                }
                case "Porsche": {
                    System.out.println("Congrats you bought a porsche! The details of your purchase are: ");
                    Porsche porsche = f.getPorsche();
                    buyer.storeInGarage(porsche);
                    porsche.displayDetails();
                    break;
                }
                default: {
                    System.out.println("Invalid car name input");
                }
                
            }
        }
    }
    buyer.garageDetails();
   


}
}