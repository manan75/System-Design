public class BillBuilder {
    
    public ShoppingBill makeBill(){
        ShoppingBill bill = new ShoppingBill();
        bill.addItem(new Shirt());
        bill.addItem(new Ball());
        bill.addItem(new Soap());
        return bill;
    }
}
