public class BuilderMain{
    public static void main(String[] args) {
        BillBuilder bill1 = new BillBuilder();
        ShoppingBill myBill = bill1.makeBill();

        myBill.display();
        float totalAmt = myBill.getBill();
        System.out.println("Total bill: "+ totalAmt);

    }
}